﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Participation_3_Classes
{
    public class Address
    {
        public int StreetNumber { get; set;}
        public string StreetName { get; set;}
        public string State { get; set;}
        public string City { get; set;}
        public int ZipCode { get; set; }

        public Address()
        {
            StreetNumber = 0;
            StreetName = String.Empty;
            State = String.Empty;
            City = String.Empty;
            ZipCode = 0;
        }

        public Address(int streetnumber, string streetname, string state, string city, int zipcode)
        {
            StreetNumber = streetnumber;
            StreetName = streetname;
            State = state;
            City = city;
            ZipCode = zipcode;
        }
    }
}
